# -*- coding: utf-8 -*-
# Plugin: MyFshare Personal Player
# Mô tả: Addon Kodi cá nhân để xem phim từ Fshare VIP
# Dùng riêng với tài khoản Fshare hợp lệ của bạn

import sys
from urllib.parse import urlencode, parse_qsl, urlparse
import requests
import xbmcaddon
import xbmc
import xbmcgui
import xbmcplugin
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor, as_completed

# ─── Khởi tạo ─────────────────────────────────────────────────────────────────

_url    = sys.argv[0]
_handle = int(sys.argv[1])

APP_ID      = 'plugin.video.myfshare'
ADDON_NAME  = 'MyFshare Player'
addon       = xbmcaddon.Addon()

# Lấy URL trang chủ từ Settings
HOME_PAGE = addon.getSetting('home_page').strip().rstrip('/')

# User-Agent giả lập trình duyệt thường
UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/120.0.0.0 Safari/537.36'
)
HEADERS = {'User-Agent': UA}

# Fshare API config
# App key công khai của Fshare (dùng để xác thực với API)
FSHARE_APP_KEY   = 'dMnqMMZMUnN5YpvKENaEhdQQ5jxDqddt'
FSHARE_UA        = 'thuviencine-FSWXQQ'
FSHARE_HEADERS   = {'User-Agent': FSHARE_UA}

FSHARE_FOLDER_PAGE_SIZE = 50
FSHARE_MAX_WORKERS      = 10

# ─── Logging ──────────────────────────────────────────────────────────────────

def log(message, level=xbmc.LOGINFO):
    xbmc.log('[{}] {}'.format(APP_ID, message), level)

# ─── Helpers ──────────────────────────────────────────────────────────────────

def get_url(**kwargs):
    """Tạo URL plugin để gọi đệ quy."""
    return '{}?{}'.format(_url, urlencode(kwargs))


def format_size(bytes_size):
    """Định dạng bytes thành chuỗi dễ đọc (KB/MB/GB)."""
    suffixes = ['B', 'KB', 'MB', 'GB', 'TB']
    i = 0
    size = float(bytes_size)
    while size >= 1024 and i < len(suffixes) - 1:
        size /= 1024
        i += 1
    return '{:.1f} {}'.format(size, suffixes[i])


def get_fshare_linkcode(url):
    """Trích xuất linkcode từ URL Fshare."""
    path  = urlparse(url).path
    parts = [p for p in path.split('/') if p]
    return parts[-1] if parts else None


def ensure_settings():
    """
    Kiểm tra Settings bắt buộc (username, password, home_page).
    Mở Settings nếu thiếu.
    """
    global HOME_PAGE

    username  = addon.getSetting('username').strip()
    password  = addon.getSetting('password').strip()
    home_page = addon.getSetting('home_page').strip().rstrip('/')

    if not username or not password or not home_page:
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'Vui lòng nhập đầy đủ:\n'
            '• Email Fshare\n'
            '• Mật khẩu Fshare\n'
            '• URL trang phim\n\n'
            'Ví dụ URL: https://thuviencine.uk'
        )
        addon.openSettings()

        # Reload sau khi đóng Settings
        username  = addon.getSetting('username').strip()
        password  = addon.getSetting('password').strip()
        home_page = addon.getSetting('home_page').strip().rstrip('/')
        HOME_PAGE = home_page

    return bool(username and password and home_page)

# ─── Fshare API ───────────────────────────────────────────────────────────────

def fshare_login():
    """
    Đăng nhập Fshare, lưu token + session_id vào Settings.
    Trả về (token, session_id).
    """
    username = addon.getSetting('username').strip()
    password = addon.getSetting('password').strip()

    if not username or not password:
        raise Exception('Chưa nhập tài khoản Fshare trong Settings')

    resp = requests.post(
        'https://api.fshare.vn/api/user/login',
        headers={'User-Agent': FSHARE_UA},
        json={
            'user_email': username,
            'password':   password,
            'app_key':    FSHARE_APP_KEY
        },
        timeout=15
    )

    data = resp.json()

    if resp.status_code != 200:
        raise Exception(data.get('msg', 'Đăng nhập Fshare thất bại'))

    token      = data.get('token', '')
    session_id = data.get('session_id', '')

    if not token or not session_id:
        raise Exception('Fshare không trả về session hợp lệ')

    # Lưu session
    addon.setSetting('_fshare_username',   username)
    addon.setSetting('_fshare_token',      token)
    addon.setSetting('_fshare_session_id', session_id)

    log('Đăng nhập Fshare thành công')
    return token, session_id


def get_fshare_session():
    """Lấy session đã lưu. Trả về (username_saved, token, session_id)."""
    return (
        addon.getSetting('_fshare_username').strip(),
        addon.getSetting('_fshare_token').strip(),
        addon.getSetting('_fshare_session_id').strip()
    )


def get_fshare_download_url(linkcode):
    """
    Lấy direct download URL từ Fshare API.
    Tự động re-login nếu session hết hạn (HTTP 201).
    """
    username = addon.getSetting('username').strip()
    saved_username, token, session_id = get_fshare_session()

    # Login nếu chưa có session hoặc tài khoản thay đổi
    if not token or not session_id or username != saved_username:
        token, session_id = fshare_login()

    file_url = 'https://www.fshare.vn/file/{}'.format(linkcode)

    def _do_download_request(token, session_id):
        return requests.post(
            'https://api.fshare.vn/api/session/download',
            headers={
                'Accept':     'application/json',
                'User-Agent': FSHARE_UA,
                'Cookie':     'session_id={}'.format(session_id)
            },
            json={
                'url':      file_url,
                'password': '',
                'token':    token,
                'zipflag':  0
            },
            timeout=15
        )

    resp = _do_download_request(token, session_id)

    # Session hết hạn → re-login rồi thử lại
    if resp.status_code == 201:
        log('Session Fshare hết hạn, đang đăng nhập lại...', xbmc.LOGWARNING)
        token, session_id = fshare_login()
        resp = _do_download_request(token, session_id)

    data         = resp.json()
    download_url = data.get('location')

    if not download_url:
        raise Exception(data.get('msg', 'Không lấy được link download'))

    return download_url


def call_fshare_folder_api(linkcode, page=1, per_page=FSHARE_FOLDER_PAGE_SIZE):
    """Gọi Fshare folder API để lấy danh sách file trong thư mục."""
    api_url = (
        'https://www.fshare.vn/api/v3/files/folder'
        '?linkcode={}&sort=type,name&page={}&per-page={}'
    ).format(linkcode, page, per_page)

    resp = requests.get(api_url, headers=HEADERS, timeout=10)
    resp.raise_for_status()
    return resp.json()

# ─── Phần Web Scraping ────────────────────────────────────────────────────────

def get_categories():
    """Lấy danh mục phim từ trang chủ."""
    categories = [
        {'name': '🔍 Tìm Kiếm',   'url': 'search'},
        {'name': '🔥 Phim Hot',    'url': '/top/'},
        {'name': '🎬 Tất Cả',      'url': '/home-page/'},
        {'name': '🎥 Phim Lẻ',     'url': '/movies/'},
        {'name': '📺 Phim Bộ',     'url': '/tv-series/'},
    ]

    try:
        resp = requests.get(HOME_PAGE, headers=HEADERS, timeout=10)
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.text, 'html.parser')
            menu = soup.select_one('li.genre-filter ul.dropdown-menu-large')
            if menu:
                for a in menu.find_all('a'):
                    name = a.get_text(strip=True)
                    url  = a.get('href', '').replace(HOME_PAGE, '')
                    if url and name:
                        categories.append({'name': '🎞 ' + name, 'url': url})
    except Exception as e:
        log('Lỗi lấy danh mục: {}'.format(e), xbmc.LOGERROR)

    return categories


def get_videos(category, page=1, query=''):
    """
    Lấy danh sách phim từ trang web.
    Trả về list dict với info phim, hoặc item đặc biệt next_page/end.
    """
    # Xây dựng URL request
    if category == 'search':
        if not query:
            kb = xbmc.Keyboard('', 'Nhập từ khóa tìm kiếm')
            kb.doModal()
            if not kb.isConfirmed():
                return []
            query = kb.getText().strip()
            if not query:
                return []

        q = query.replace(' ', '+')
        url = (
            HOME_PAGE + '/?s={}'.format(q)
            if page == 1
            else HOME_PAGE + '/page/{}/?s={}'.format(page, q)
        )

    elif category == '/home-page/':
        url = HOME_PAGE if page == 1 else HOME_PAGE + '/page/{}/'.format(page)

    else:
        cat = '/' + category.strip('/') + '/'
        url = (
            HOME_PAGE + cat
            if page == 1
            else HOME_PAGE + cat + 'page/{}/'.format(page)
        )

    # Gọi request
    try:
        resp = requests.get(url, headers=HEADERS, timeout=10)
    except Exception as e:
        log('Request lỗi: {}'.format(e), xbmc.LOGERROR)
        return [{'name': '[COLOR red][B]• Lỗi kết nối •[/B][/COLOR]', 'end': True}]

    if resp.status_code != 200:
        return [{'name': '[COLOR red][B]• Đã hết nội dung •[/B][/COLOR]', 'end': True}]

    soup  = BeautifulSoup(resp.text, 'html.parser')
    items = soup.select('div[id^="post-"].item')

    if not items:
        return [{'name': '[COLOR red][B]• Không tìm thấy phim •[/B][/COLOR]', 'end': True}]

    videos = []
    added  = set()

    for item in items:
        a = item.select_one('a[rel="bookmark"]')
        if not a:
            continue

        href = a.get('href')
        if not href or href in added:
            continue
        added.add(href)

        # Post ID
        item_id = item.get('id', '')
        if not item_id.startswith('post-'):
            continue
        post_id = item_id.replace('post-', '')

        # Title
        title = a.get('title', '')
        img   = item.find('img')
        thumb = ''

        if img:
            thumb = (
                img.get('data-original')
                or img.get('data-src')
                or img.get('src', '')
            )
            if not title:
                title = img.get('alt', '')

        if not title:
            title = a.get_text(strip=True)
        if not title:
            continue

        # Metadata phụ
        plot    = ''
        rating  = 0.0
        year    = 0
        genre   = ''
        quality = ''

        desc_el = item.select_one('.movie-description')
        if desc_el:
            plot = desc_el.get_text(strip=True)

        imdb_el = item.select_one('.imdb-rating')
        if imdb_el:
            try:
                rating = float(
                    imdb_el.get_text(strip=True)
                    .replace('N/A', '').replace('/10', '')
                    .replace('IMDb', '').replace('★', '').strip()
                )
            except:
                pass

        date_el = item.select_one('.movie-date')
        if date_el:
            try:
                year = int(date_el.get_text(strip=True))
            except:
                pass

        genre_el = item.select_one('.genre')
        if genre_el:
            genre = genre_el.get_text(strip=True)

        quality_el = item.select_one('.item-quality')
        if quality_el:
            quality = quality_el.get_text(strip=True)

        videos.append({
            'name':    title,
            'id':      post_id,
            'thumb':   thumb,
            'plot':    plot,
            'rating':  rating,
            'year':    year,
            'genre':   genre,
            'quality': quality,
        })

    if not videos:
        return [{'name': '[COLOR red][B]• Không tìm thấy phim •[/B][/COLOR]', 'end': True}]

    # Nút sang trang tiếp
    videos.append({
        'name':      '[COLOR yellow][B]» Trang Tiếp Theo ({}) «[/B][/COLOR]'.format(page + 1),
        'category':  category,
        'page':      page + 1,
        'query':     query,
        'next_page': True,
    })

    return videos


def get_links(post_id):
    """
    Lấy link Fshare từ trang download của phim.
    Trả về dict {index: {'name': ..., 'url': ..., ...}}
    """
    url  = HOME_PAGE + '/download?id={}'.format(post_id)
    resp = requests.get(url, headers=HEADERS, timeout=10)

    if resp.status_code != 200:
        return {}

    soup      = BeautifulSoup(resp.text, 'html.parser')
    videolink = {}
    idx       = 0

    for li in soup.select('div.movie-actions li'):
        a    = li.find('a')
        if not a:
            continue
        href = a.get('href', '').strip()
        if not href:
            continue

        title = li.get('title', '').strip()
        if not title:
            span = a.find('span')
            if span:
                title = span.get_text(strip=True)
        if not title:
            title = 'Tập {}'.format(idx + 1)

        videolink[idx] = {'name': title, 'url': href}
        idx += 1

    # Gọi song song Fshare API để lấy thông tin file/folder
    def fetch_info(index, item):
        linkcode = get_fshare_linkcode(item.get('url', ''))
        if not linkcode:
            return index, None
        try:
            data = call_fshare_folder_api(linkcode)
            info = data.get('current', {})
            return index, {
                'current.name': info.get('name'),
                'current.type': info.get('type'),
                'current.size': info.get('size'),
            }
        except Exception as e:
            log('Fshare folder API lỗi: {}'.format(e), xbmc.LOGERROR)
            return index, None

    with ThreadPoolExecutor(max_workers=FSHARE_MAX_WORKERS) as ex:
        futures = [ex.submit(fetch_info, i, v) for i, v in videolink.items()]
        for future in as_completed(futures):
            i, result = future.result()
            if result:
                videolink[i].update(result)

    return videolink

# ─── Kodi UI Functions ────────────────────────────────────────────────────────

def list_categories():
    """Hiển thị danh mục phim."""
    for cat in get_categories():
        item = xbmcgui.ListItem(label=cat['name'])
        item.getVideoInfoTag().setTitle(cat['name'])
        url  = get_url(action='listing', category=cat['url'])
        xbmcplugin.addDirectoryItem(_handle, url, item, True)
    xbmcplugin.endOfDirectory(_handle)


def list_videos(category, page=1, query=''):
    """Hiển thị danh sách phim."""
    videos = get_videos(category, page, query)

    for video in videos:
        label = video['name']
        item  = xbmcgui.ListItem(label=label)

        # Item kết thúc
        if video.get('end'):
            item.setProperty('IsPlayable', 'false')
            xbmcplugin.addDirectoryItem(_handle, '', item, False)
            continue

        # Nút trang tiếp
        if video.get('next_page'):
            url = get_url(
                action   = 'listing',
                category = video['category'],
                page     = video['page'],
                query    = video.get('query', '')
            )
            xbmcplugin.addDirectoryItem(_handle, url, item, True)
            continue

        # Item phim bình thường
        info_tag = item.getVideoInfoTag()
        info_tag.setTitle(video['name'])
        info_tag.setMediaType('movie')

        if video.get('rating'):
            info_tag.setRating(video['rating'])
        if video.get('year'):
            info_tag.setYear(video['year'])

        plot = video.get('plot', '')
        if video.get('quality'):
            plot = 'Chất lượng: [COLOR yellow]{}[/COLOR]\n\n{}'.format(
                video['quality'], plot
            )
        info_tag.setPlot(plot)

        if video.get('genre'):
            info_tag.setGenres([g.strip() for g in video['genre'].split(',') if g.strip()])

        # Thumbnail
        thumb = video.get('thumb', '')
        parts = thumb.split('/')
        if len(parts) > 5:
            parts[5] = 'original'
        fanart = '/'.join(parts)
        item.setArt({'thumb': fanart, 'icon': '', 'fanart': ''})

        url = get_url(action='listing', video=video['id'])
        xbmcplugin.addDirectoryItem(_handle, url, item, True)

    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle)


def list_links(post_id):
    """Hiển thị danh sách link (file/folder Fshare) của một phim."""
    videolink = get_links(post_id)

    if not videolink:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Không tìm thấy link nào cho phim này.')
        xbmcplugin.endOfDirectory(_handle)
        return

    for v in videolink.values():
        item_type = v.get('current.type', 0)
        label     = v['name']

        # File → hiển thị dung lượng
        if item_type == 1:
            size  = v.get('current.size', 0)
            label = '{} [COLOR yellow]| {}[/COLOR]'.format(label, format_size(size))

        item      = xbmcgui.ListItem(label=label)
        linkcode  = get_fshare_linkcode(v['url'])
        is_folder = True

        if item_type == 1:
            # File → có thể phát
            item.getVideoInfoTag().setTitle(label)
            item.setProperty('IsPlayable', 'true')
            url       = get_url(action='play_fshare', linkcode=linkcode)
            is_folder = False
        else:
            # Folder → duyệt tiếp
            url = get_url(action='listing', fshare=linkcode, page='1')

        xbmcplugin.addDirectoryItem(_handle, url, item, is_folder)

    xbmcplugin.endOfDirectory(_handle)


def list_fshare_folder(linkcode, page=1):
    """Hiển thị nội dung thư mục Fshare."""
    if not linkcode:
        xbmcplugin.endOfDirectory(_handle)
        return

    try:
        data       = call_fshare_folder_api(linkcode, page)
        items      = data.get('items', [])
        has_next   = len(items) >= FSHARE_FOLDER_PAGE_SIZE
    except Exception as e:
        log('Lỗi lấy folder Fshare: {}'.format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, 'Lỗi khi tải thư mục:\n{}'.format(e))
        xbmcplugin.endOfDirectory(_handle)
        return

    for item in items:
        item_type    = item.get('type', 0)
        label        = item.get('name', 'Unknown')
        item_lc      = item.get('linkcode', '')

        if item_type == 1:
            size  = item.get('size', 0)
            label = '{} [COLOR yellow]| {}[/COLOR]'.format(label, format_size(size))

        li        = xbmcgui.ListItem(label=label)
        is_folder = True

        if item_type == 1:
            li.getVideoInfoTag().setTitle(label)
            li.setProperty('IsPlayable', 'true')
            url       = get_url(action='play_fshare', linkcode=item_lc)
            is_folder = False
        else:
            url = get_url(action='listing', fshare=item_lc, page='1')

        xbmcplugin.addDirectoryItem(_handle, url, li, is_folder)

    if has_next:
        next_li = xbmcgui.ListItem(
            label='[COLOR yellow][B]» Trang Tiếp Theo ({}) «[/B][/COLOR]'.format(page + 1)
        )
        next_url = get_url(action='listing', fshare=linkcode, page=str(page + 1))
        xbmcplugin.addDirectoryItem(_handle, next_url, next_li, True)

    xbmcplugin.endOfDirectory(_handle)


def play_fshare(linkcode):
    """Lấy direct link và phát video từ Fshare."""
    try:
        stream_url = get_fshare_download_url(linkcode)
        play_item  = xbmcgui.ListItem(path=stream_url)
        xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
    except Exception as e:
        log('Lỗi phát video: {}'.format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'Lỗi khi phát video:\n{}\n\nKiểm tra lại tài khoản Fshare VIP trong Settings.'.format(e)
        )
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

# ─── Router ───────────────────────────────────────────────────────────────────

def router(paramstring):
    """
    Điều hướng các action từ paramstring URL.
    """
    params = dict(parse_qsl(paramstring))

    if params:
        action = params.get('action')

        if action == 'listing':
            category = params.get('category')
            if category:
                list_videos(category, int(params.get('page', '1')), params.get('query', ''))
                return

            video = params.get('video')
            if video:
                list_links(video)
                return

            fshare = params.get('fshare')
            if fshare:
                list_fshare_folder(fshare, int(params.get('page', '1')))
                return

        elif action == 'play_fshare':
            play_fshare(params.get('linkcode', ''))
            return

        raise ValueError('Paramstring không hợp lệ: {}'.format(paramstring))

    # Màn hình gốc
    if not ensure_settings():
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'Cần nhập đầy đủ thông tin trong Settings trước khi sử dụng.'
        )
        return

    list_categories()


if __name__ == '__main__':
    router(sys.argv[2][1:])
