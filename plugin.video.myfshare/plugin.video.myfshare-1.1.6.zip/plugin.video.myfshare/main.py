# -*- coding: utf-8 -*-
# Plugin: MyFshare Personal Player v1.1.0

import sys
import csv
import io
from urllib.parse import urlencode, parse_qsl, urlparse
import requests
import xbmcaddon
import xbmc
import xbmcgui
import xbmcplugin
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor, as_completed

# ─── Khởi tạo ─────────────────────────────────────────────────────────────────

_url    = sys.argv[0]
_handle = int(sys.argv[1])

APP_ID      = 'plugin.video.myfshare'
ADDON_NAME  = 'MyFshare Player'
addon       = xbmcaddon.Addon()

# URL mặc định — không cần nhập trong Settings
DEFAULT_HOME_PAGE = 'https://thuviencine.uk'

UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/120.0.0.0 Safari/537.36'
)
HEADERS = {'User-Agent': UA}

# Fshare API
FSHARE_APP_KEY = 'dMnqMMZMUnN5YpvKENaEhdQQ5jxDqddt'
FSHARE_UA      = 'thuviencine-FSWXQQ'

FSHARE_FOLDER_PAGE_SIZE = 50
FSHARE_MAX_WORKERS      = 10

# ─── Logging ──────────────────────────────────────────────────────────────────

def log(message, level=xbmc.LOGINFO):
    xbmc.log('[{}] {}'.format(APP_ID, message), level)

# ─── Helpers ──────────────────────────────────────────────────────────────────

def get_home_page():
    """Lấy URL trang chủ — luôn dùng mặc định."""
    return DEFAULT_HOME_PAGE

def get_url(**kwargs):
    return '{}?{}'.format(_url, urlencode(kwargs))

def format_size(bytes_size):
    suffixes = ['B', 'KB', 'MB', 'GB', 'TB']
    i, size = 0, float(bytes_size)
    while size >= 1024 and i < len(suffixes) - 1:
        size /= 1024; i += 1
    return '{:.1f} {}'.format(size, suffixes[i])

def get_fshare_linkcode(url):
    path  = urlparse(url).path
    parts = [p for p in path.split('/') if p]
    return parts[-1] if parts else None

def resolve_short_url(short_url):
    """
    Resolve URL rút gọn (TinyURL, bit.ly, v.v.) về URL gốc.
    """
    try:
        r = requests.head(
            short_url,
            headers=HEADERS,
            allow_redirects=True,
            timeout=10
        )
        return r.url
    except Exception as e:
        log('Resolve short URL lỗi: {}'.format(e), xbmc.LOGERROR)
        return short_url

def ensure_fshare_settings():
    """Kiểm tra email + password Fshare."""
    username = addon.getSetting('username').strip()
    password = addon.getSetting('password').strip()
    if not username or not password:
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'Vui lòng nhập Email và Password Fshare trong Settings.'
        )
        addon.openSettings()
        username = addon.getSetting('username').strip()
        password = addon.getSetting('password').strip()
    return bool(username and password)

# ─── Fshare API ───────────────────────────────────────────────────────────────

def fshare_login():
    username = addon.getSetting('username').strip()
    password = addon.getSetting('password').strip()
    if not username or not password:
        raise Exception('Chưa nhập tài khoản Fshare trong Settings')

    resp = requests.post(
        'https://api.fshare.vn/api/user/login',
        headers={'User-Agent': FSHARE_UA},
        json={
            'user_email': username,
            'password':   password,
            'app_key':    FSHARE_APP_KEY
        },
        timeout=15
    )
    data = resp.json()
    if resp.status_code != 200:
        raise Exception(data.get('msg', 'Đăng nhập Fshare thất bại'))

    token      = data.get('token', '')
    session_id = data.get('session_id', '')
    if not token or not session_id:
        raise Exception('Fshare không trả về session hợp lệ')

    addon.setSetting('_fshare_username',   username)
    addon.setSetting('_fshare_token',      token)
    addon.setSetting('_fshare_session_id', session_id)
    log('Đăng nhập Fshare thành công')
    return token, session_id

def get_fshare_session():
    return (
        addon.getSetting('_fshare_username').strip(),
        addon.getSetting('_fshare_token').strip(),
        addon.getSetting('_fshare_session_id').strip()
    )

def get_fshare_download_url(linkcode):
    username = addon.getSetting('username').strip()
    saved_username, token, session_id = get_fshare_session()

    if not token or not session_id or username != saved_username:
        token, session_id = fshare_login()

    file_url = 'https://www.fshare.vn/file/{}'.format(linkcode)

    def _request(token, session_id):
        return requests.post(
            'https://api.fshare.vn/api/session/download',
            headers={
                'Accept':     'application/json',
                'User-Agent': FSHARE_UA,
                'Cookie':     'session_id={}'.format(session_id)
            },
            json={
                'url':      file_url,
                'password': '',
                'token':    token,
                'zipflag':  0
            },
            timeout=15
        )

    resp = _request(token, session_id)
    if resp.status_code == 201:
        log('Session hết hạn, re-login...', xbmc.LOGWARNING)
        token, session_id = fshare_login()
        resp = _request(token, session_id)

    data         = resp.json()
    download_url = data.get('location')
    if not download_url:
        raise Exception(data.get('msg', 'Không lấy được link download'))
    return download_url

def call_fshare_folder_api(linkcode, page=1, per_page=FSHARE_FOLDER_PAGE_SIZE):
    api_url = (
        'https://www.fshare.vn/api/v3/files/folder'
        '?linkcode={}&sort=type,name&page={}&per-page={}'
    ).format(linkcode, page, per_page)
    resp = requests.get(api_url, headers=HEADERS, timeout=10)
    resp.raise_for_status()
    return resp.json()

# ─── Google Sheets ────────────────────────────────────────────────────────────

def get_sheets_csv_url(sheets_url):
    """
    Chuyển URL Google Sheets thường → URL CSV export.
    Hỗ trợ cả URL publish-to-web và URL thường.
    """
    if 'output=csv' in sheets_url:
        return sheets_url

    # URL dạng: https://docs.google.com/spreadsheets/d/SHEET_ID/...
    if '/spreadsheets/d/' in sheets_url:
        parts   = sheets_url.split('/spreadsheets/d/')
        sheet_id = parts[1].split('/')[0]

        # Lấy gid nếu có
        gid = '0'
        if 'gid=' in sheets_url:
            gid = sheets_url.split('gid=')[1].split('&')[0].split('#')[0]

        return (
            'https://docs.google.com/spreadsheets/d/{}'
            '/export?format=csv&gid={}'
        ).format(sheet_id, gid)

    return sheets_url

def load_sheets_data():
    """
    Đọc dữ liệu từ Google Sheets.
    Cột: Tên | URL Fshare | Ảnh (tùy chọn) | Mô tả (tùy chọn)
    """
    sheets_url = addon.getSetting('sheets_url').strip()
    if not sheets_url:
        return []

    csv_url = get_sheets_csv_url(sheets_url)

    try:
        resp = requests.get(csv_url, headers=HEADERS, timeout=15)
        resp.raise_for_status()

        text    = resp.content.decode('utf-8-sig')
        reader  = csv.reader(io.StringIO(text))
        rows    = list(reader)

        items = []
        for i, row in enumerate(rows):
            # Bỏ qua header (dòng đầu) và dòng trống
            if i == 0:
                continue
            if not row or not row[0].strip():
                continue

            name      = row[0].strip() if len(row) > 0 else ''
            fshare_url = row[1].strip() if len(row) > 1 else ''
            thumb     = row[2].strip() if len(row) > 2 else ''
            plot      = row[3].strip() if len(row) > 3 else ''

            if not name or not fshare_url:
                continue

            items.append({
                'name':       name,
                'fshare_url': fshare_url,
                'thumb':      thumb,
                'plot':       plot
            })

        return items

    except Exception as e:
        log('Lỗi đọc Google Sheets: {}'.format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            'Lỗi đọc Google Sheets: {}'.format(str(e)[:50]),
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )
        return []

def list_sheets_items():
    """Hiển thị danh sách phim từ Google Sheets."""
    items = load_sheets_data()

    if not items:
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'Không có dữ liệu từ Google Sheets.\n'
            'Kiểm tra lại URL trong Settings → Google Sheets.'
        )
        xbmcplugin.endOfDirectory(_handle)
        return

    for item in items:
        label    = item['name']
        li       = xbmcgui.ListItem(label=label)
        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(label)

        if item.get('plot'):
            info_tag.setPlot(item['plot'])

        if item.get('thumb'):
            li.setArt({'thumb': item['thumb'], 'icon': item['thumb']})

        # Xác định link Fshare (file hay folder)
        fshare_url = item['fshare_url']
        linkcode   = get_fshare_linkcode(fshare_url)
        is_folder  = True

        if '/file/' in fshare_url:
            # File trực tiếp → phát ngay
            li.setProperty('IsPlayable', 'true')
            url       = get_url(action='play_fshare', linkcode=linkcode)
            is_folder = False
        else:
            # Folder → duyệt tiếp
            url = get_url(action='listing', fshare=linkcode, page='1')

        xbmcplugin.addDirectoryItem(_handle, url, li, is_folder)

    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle)

# ─── Nhập link rút gọn ────────────────────────────────────────────────────────

def play_short_url():
    """
    Người dùng nhập code TinyURL (ví dụ: ydk4psev)
    → resolve → lấy linkcode Fshare → phát.
    Cũng hỗ trợ nhập thẳng linkcode Fshare hoặc URL đầy đủ.
    """
    kb = xbmc.Keyboard('', 'Nhập code TinyURL hoặc linkcode Fshare')
    kb.doModal()
    if not kb.isConfirmed():
        return

    text = kb.getText().strip()
    if not text:
        return

    # Trường hợp 1: nhập URL đầy đủ (https://...)
    if text.startswith('http'):
        final_url = text

        # Nếu là link rút gọn → resolve
        if 'tinyurl.com' in text or 'bit.ly' in text or 'shorturl' in text:
            xbmcgui.Dialog().notification(
                ADDON_NAME, 'Đang resolve link...', xbmcgui.NOTIFICATION_INFO, 2000
            )
            final_url = resolve_short_url(text)

        # Lấy linkcode từ URL Fshare
        linkcode = get_fshare_linkcode(final_url)

    # Trường hợp 2: nhập code TinyURL (vd: ydk4psev)
    elif len(text) < 30 and '/' not in text and '.' not in text:
        short_url = 'https://tinyurl.com/{}'.format(text)
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'Đang resolve TinyURL...', xbmcgui.NOTIFICATION_INFO, 2000
        )
        final_url = resolve_short_url(short_url)
        linkcode  = get_fshare_linkcode(final_url)

    # Trường hợp 3: nhập thẳng linkcode Fshare (vd: Q7JS2O1P8S1FQ8N)
    else:
        linkcode = text
        final_url = 'https://www.fshare.vn/file/{}'.format(text)

    if not linkcode:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Không xác định được link Fshare từ:\n{}'.format(text))
        return

    log('play_short_url → linkcode: {}'.format(linkcode))

    # Folder → hiện danh sách file bên trong
    if '/folder/' in final_url:
        items = []
        li = xbmcgui.ListItem(label='[Xem folder] ' + linkcode)
        li.setProperty('IsPlayable', 'false')
        url = get_url(action='listing', fshare=linkcode, page='1')
        xbmcplugin.addDirectoryItem(_handle, url, li, True)
        xbmcplugin.endOfDirectory(_handle)
        return

    # File → lấy tên file từ Fshare API rồi tạo item playable
    file_name = linkcode  # fallback
    file_size = 0
    try:
        data      = call_fshare_folder_api(linkcode)
        current   = data.get('current', {})
        file_name = current.get('name', linkcode)
        file_size = current.get('size', 0)
    except Exception as e:
        log('Khong lay duoc ten file: {}'.format(e), xbmc.LOGWARNING)

    label = file_name
    if file_size:
        label = '{} [COLOR yellow]| {}[/COLOR]'.format(file_name, format_size(file_size))

    play_url = get_url(action='play_fshare', linkcode=linkcode)
    li = xbmcgui.ListItem(label=label)
    li.setProperty('IsPlayable', 'true')
    li.getVideoInfoTag().setTitle(file_name)
    xbmcplugin.addDirectoryItem(_handle, play_url, li, False)
    xbmcplugin.endOfDirectory(_handle)

# ─── Web Scraping (ThuVienCine) ───────────────────────────────────────────────

def get_categories():
    HOME_PAGE  = get_home_page()
    categories = [
        {'name': 'Tim Kiem',              'url': 'search'},
        {'name': 'Danh Sach Cua Toi',      'url': 'mysheets'},
        {'name': 'Nhap Link / TinyURL',    'url': 'shorturl'},
        {'name': 'Phim Hot',               'url': '/top/'},
        {'name': 'Tat Ca',                 'url': '/home-page/'},
        {'name': 'Phim Le',                'url': '/movies/'},
        {'name': 'Phim Bo',                'url': '/tv-series/'},
    ]
    try:
        resp = requests.get(HOME_PAGE, headers=HEADERS, timeout=10)
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.text, 'html.parser')
            menu = soup.select_one('li.genre-filter ul.dropdown-menu-large')
            if menu:
                for a in menu.find_all('a'):
                    name = a.get_text(strip=True)
                    url  = a.get('href', '').replace(HOME_PAGE, '')
                    if url and name:
                        categories.append({'name': '[' + name + ']', 'url': url})
    except Exception as e:
        log('Lỗi lấy danh mục: {}'.format(e), xbmc.LOGERROR)
    return categories

def get_videos(category, page=1, query=''):
    HOME_PAGE = get_home_page()

    if category == 'search':
        if not query:
            kb = xbmc.Keyboard('', 'Nhập từ khóa tìm kiếm')
            kb.doModal()
            if not kb.isConfirmed():
                return []
            query = kb.getText().strip()
            if not query:
                return []
        q   = query.replace(' ', '+')
        url = (
            HOME_PAGE + '/?s={}'.format(q)
            if page == 1
            else HOME_PAGE + '/page/{}/?s={}'.format(page, q)
        )
    elif category == '/home-page/':
        url = HOME_PAGE if page == 1 else HOME_PAGE + '/page/{}/'.format(page)
    else:
        cat = '/' + category.strip('/') + '/'
        url = (
            HOME_PAGE + cat
            if page == 1
            else HOME_PAGE + cat + 'page/{}/'.format(page)
        )

    try:
        resp = requests.get(url, headers=HEADERS, timeout=10)
    except Exception as e:
        log('Request lỗi: {}'.format(e), xbmc.LOGERROR)
        return [{'name': '[COLOR red][B]• Lỗi kết nối •[/B][/COLOR]', 'end': True}]

    if resp.status_code != 200:
        return [{'name': '[COLOR red][B]• Đã hết nội dung •[/B][/COLOR]', 'end': True}]

    soup  = BeautifulSoup(resp.text, 'html.parser')
    items = soup.select('div[id^="post-"].item')

    if not items:
        return [{'name': '[COLOR red][B]• Không tìm thấy phim •[/B][/COLOR]', 'end': True}]

    videos = []
    added  = set()

    for item in items:
        a = item.select_one('a[rel="bookmark"]')
        if not a:
            continue
        href = a.get('href')
        if not href or href in added:
            continue
        added.add(href)

        item_id = item.get('id', '')
        if not item_id.startswith('post-'):
            continue
        post_id = item_id.replace('post-', '')

        title = a.get('title', '')
        img   = item.find('img')
        thumb = ''
        if img:
            thumb = img.get('data-original') or img.get('data-src') or img.get('src', '')
            if not title:
                title = img.get('alt', '')
        if not title:
            title = a.get_text(strip=True)
        if not title:
            continue

        plot, rating, year, genre, quality = '', 0.0, 0, '', ''

        desc_el = item.select_one('.movie-description')
        if desc_el:
            plot = desc_el.get_text(strip=True)

        imdb_el = item.select_one('.imdb-rating')
        if imdb_el:
            try:
                rating = float(
                    imdb_el.get_text(strip=True)
                    .replace('N/A','').replace('/10','')
                    .replace('IMDb','').replace('★','').strip()
                )
            except: pass

        date_el = item.select_one('.movie-date')
        if date_el:
            try: year = int(date_el.get_text(strip=True))
            except: pass

        genre_el = item.select_one('.genre')
        if genre_el:
            genre = genre_el.get_text(strip=True)

        quality_el = item.select_one('.item-quality')
        if quality_el:
            quality = quality_el.get_text(strip=True)

        videos.append({
            'name': title, 'id': post_id, 'thumb': thumb,
            'plot': plot, 'rating': rating, 'year': year,
            'genre': genre, 'quality': quality
        })

    if not videos:
        return [{'name': '[COLOR red][B]• Không tìm thấy phim •[/B][/COLOR]', 'end': True}]

    videos.append({
        'name':      '[COLOR yellow][B]» Trang Tiếp Theo ({}) «[/B][/COLOR]'.format(page + 1),
        'category':  category,
        'page':      page + 1,
        'query':     query,
        'next_page': True
    })
    return videos

def get_links(post_id):
    HOME_PAGE = get_home_page()
    url  = HOME_PAGE + '/download?id={}'.format(post_id)
    resp = requests.get(url, headers=HEADERS, timeout=10)
    if resp.status_code != 200:
        return {}

    soup      = BeautifulSoup(resp.text, 'html.parser')
    videolink = {}
    idx       = 0

    for li in soup.select('div.movie-actions li'):
        a    = li.find('a')
        if not a: continue
        href = a.get('href', '').strip()
        if not href: continue
        title = li.get('title', '').strip()
        if not title:
            span = a.find('span')
            if span: title = span.get_text(strip=True)
        if not title:
            title = 'Tập {}'.format(idx + 1)
        videolink[idx] = {'name': title, 'url': href}
        idx += 1

    def fetch_info(index, item):
        linkcode = get_fshare_linkcode(item.get('url', ''))
        if not linkcode: return index, None
        try:
            data = call_fshare_folder_api(linkcode)
            info = data.get('current', {})
            return index, {
                'current.name': info.get('name'),
                'current.type': info.get('type'),
                'current.size': info.get('size')
            }
        except Exception as e:
            log('Fshare folder API lỗi: {}'.format(e), xbmc.LOGERROR)
            return index, None

    with ThreadPoolExecutor(max_workers=FSHARE_MAX_WORKERS) as ex:
        futures = [ex.submit(fetch_info, i, v) for i, v in videolink.items()]
        for future in as_completed(futures):
            i, result = future.result()
            if result: videolink[i].update(result)

    return videolink

# ─── Kodi UI ──────────────────────────────────────────────────────────────────

def list_categories():
    for cat in get_categories():
        li = xbmcgui.ListItem(label=cat['name'])
        li.getVideoInfoTag().setTitle(cat['name'])
        url = get_url(action='listing', category=cat['url'])
        xbmcplugin.addDirectoryItem(_handle, url, li, True)
    xbmcplugin.endOfDirectory(_handle)

def list_videos(category, page=1, query=''):
    videos = get_videos(category, page, query)
    for video in videos:
        label = video['name']
        li    = xbmcgui.ListItem(label=label)

        if video.get('end'):
            li.setProperty('IsPlayable', 'false')
            xbmcplugin.addDirectoryItem(_handle, '', li, False)
            continue

        if video.get('next_page'):
            url = get_url(
                action='listing', category=video['category'],
                page=video['page'], query=video.get('query', '')
            )
            xbmcplugin.addDirectoryItem(_handle, url, li, True)
            continue

        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(video['name'])
        info_tag.setMediaType('movie')
        if video.get('rating'): info_tag.setRating(video['rating'])
        if video.get('year'):   info_tag.setYear(video['year'])

        plot = video.get('plot', '')
        if video.get('quality'):
            plot = 'Chất lượng: [COLOR yellow]{}[/COLOR]\n\n{}'.format(video['quality'], plot)
        info_tag.setPlot(plot)

        if video.get('genre'):
            info_tag.setGenres([g.strip() for g in video['genre'].split(',') if g.strip()])

        thumb = video.get('thumb', '')
        parts = thumb.split('/')
        if len(parts) > 5: parts[5] = 'original'
        fanart = '/'.join(parts)
        li.setArt({'thumb': fanart, 'icon': '', 'fanart': ''})

        url = get_url(action='listing', video=video['id'])
        xbmcplugin.addDirectoryItem(_handle, url, li, True)

    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle)

def list_links(post_id):
    videolink = get_links(post_id)
    if not videolink:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Không tìm thấy link nào cho phim này.')
        xbmcplugin.endOfDirectory(_handle)
        return

    for v in videolink.values():
        item_type = v.get('current.type', 0)
        label     = v['name']
        if item_type == 1:
            label = '{} [COLOR yellow]| {}[/COLOR]'.format(label, format_size(v.get('current.size', 0)))

        li       = xbmcgui.ListItem(label=label)
        linkcode = get_fshare_linkcode(v['url'])
        is_folder = True

        if item_type == 1:
            li.getVideoInfoTag().setTitle(label)
            li.setProperty('IsPlayable', 'true')
            url       = get_url(action='play_fshare', linkcode=linkcode)
            is_folder = False
        else:
            url = get_url(action='listing', fshare=linkcode, page='1')

        xbmcplugin.addDirectoryItem(_handle, url, li, is_folder)
    xbmcplugin.endOfDirectory(_handle)

def list_fshare_folder(linkcode, page=1):
    if not linkcode:
        xbmcplugin.endOfDirectory(_handle)
        return
    try:
        data     = call_fshare_folder_api(linkcode, page)
        items    = data.get('items', [])
        has_next = len(items) >= FSHARE_FOLDER_PAGE_SIZE
    except Exception as e:
        log('Lỗi folder Fshare: {}'.format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, 'Lỗi khi tải thư mục:\n{}'.format(e))
        xbmcplugin.endOfDirectory(_handle)
        return

    for item in items:
        item_type = item.get('type', 0)
        label     = item.get('name', 'Unknown')
        item_lc   = item.get('linkcode', '')

        if item_type == 1:
            label = '{} [COLOR yellow]| {}[/COLOR]'.format(label, format_size(item.get('size', 0)))

        li        = xbmcgui.ListItem(label=label)
        is_folder = True

        if item_type == 1:
            li.getVideoInfoTag().setTitle(label)
            li.setProperty('IsPlayable', 'true')
            url       = get_url(action='play_fshare', linkcode=item_lc)
            is_folder = False
        else:
            url = get_url(action='listing', fshare=item_lc, page='1')

        xbmcplugin.addDirectoryItem(_handle, url, li, is_folder)

    if has_next:
        next_li = xbmcgui.ListItem(
            label='[COLOR yellow][B]» Trang Tiếp Theo ({}) «[/B][/COLOR]'.format(page + 1)
        )
        xbmcplugin.addDirectoryItem(
            _handle,
            get_url(action='listing', fshare=linkcode, page=str(page + 1)),
            next_li, True
        )
    xbmcplugin.endOfDirectory(_handle)

def play_fshare(linkcode):
    try:
        stream_url = get_fshare_download_url(linkcode)
        play_item  = xbmcgui.ListItem(path=stream_url)
        xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
    except Exception as e:
        log('Lỗi phát video: {}'.format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'Lỗi khi phát video:\n{}\n\nKiểm tra lại tài khoản Fshare VIP.'.format(e)
        )
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

# ─── Router ───────────────────────────────────────────────────────────────────

def router(paramstring):
    params = dict(parse_qsl(paramstring))

    if params:
        action = params.get('action')

        if action == 'listing':
            category = params.get('category')
            if category == 'mysheets':
                list_sheets_items()
                return
            if category == 'shorturl':
                play_short_url()
                return
            if category:
                list_videos(category, int(params.get('page', '1')), params.get('query', ''))
                return

            video = params.get('video')
            if video:
                list_links(video)
                return

            fshare = params.get('fshare')
            if fshare:
                list_fshare_folder(fshare, int(params.get('page', '1')))
                return

        elif action == 'play_fshare':
            play_fshare(params.get('linkcode', ''))
            return

        raise ValueError('Paramstring không hợp lệ: {}'.format(paramstring))

    # Màn hình gốc
    if not ensure_fshare_settings():
        xbmcgui.Dialog().ok(ADDON_NAME, 'Cần nhập Email và Password Fshare trong Settings.')
        return

    list_categories()

if __name__ == '__main__':
    router(sys.argv[2][1:])
